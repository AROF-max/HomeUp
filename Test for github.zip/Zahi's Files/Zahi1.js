// FIREBASE SETUP
const firebaseConfig = {
  apiKey: "AIzaSyBRaI4HV_XSp2uoJUWTYiBu5wZhU_rkvhI",
  authDomain: "clicklearn-hackathon-2f31c.firebaseapp.com",
  projectId: "clicklearn-hackathon-2f31c",
  storageBucket: "clicklearn-hackathon-2f31c.firebasestorage.app",
  messagingSenderId: "107325774032",
  appId: "1:107325774032:web:3824b8a3f0892c756b66d5"
};

firebase.initializeApp(firebaseConfig);

const auth = firebase.auth();
const db = firebase.firestore();

// MAIN VARIABLES


// LOGIN FUNCTION
function login(){
  const email = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  
  console.log(email);
  console.log(password);
  
  auth.signInWithEmailAndPassword(email, password).then((userCredential) => {
    const user = userCredential.user;
    const uid = user.uid;
    
    console.log(uid);
    
    db.collection("Families").doc(uid).get().then((doc) => {
      console.log(doc.exists);
      console.log(doc.data());
      
      const userData = doc.data();
      console.log(userData.Name);
    })
  })
}